package work;

import java.util.Scanner;

public class TVUser {

	public static void main(String[] args) {
//		TV tv = new LgTV();
		BeanFactory factory = new BeanFactory();
		
		// ����ڷκ��� ���ڿ� �Է� ����
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		
		TV tv = (TV)factory.getBean(input);
		tv.powerOn();
		tv.volumeUp();
		tv.volumeDown();
		tv.powerOff();
		
		
	}

}
