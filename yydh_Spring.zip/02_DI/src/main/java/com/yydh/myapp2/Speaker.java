package com.yydh.myapp2;

public interface Speaker {

	void volumeUp();

	void volumeDown();

}