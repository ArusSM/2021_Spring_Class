package com.yydh.myapp2;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TVUser {

	public static void main(String[] args) {

		
//		SonySpeaker speaker = new SonySpeaker();
//		TV tv = new SamsungTV(speaker);

		//1. xml�ε�
		AbstractApplicationContext factory
		= new GenericXmlApplicationContext("applicationContext2.xml");
		
		//2. Spring �����̳� java �Ҵ�
		TV tv = (TV)factory.getBean("tv");
		
		
		//3. java �޼ҵ� ����
		tv.powerOn();
		tv.volumeUp();
		tv.volumeDown();
		tv.powerOff();

		
		//3. �����̳� �ݱ�
		factory.close();
		
	}

}
