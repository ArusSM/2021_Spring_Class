package com.yydh.myapp3;

public interface Speaker {

	void volumeUp();

	void volumeDown();

}