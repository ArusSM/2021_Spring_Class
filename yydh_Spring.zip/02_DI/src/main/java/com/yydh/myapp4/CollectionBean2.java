package com.yydh.myapp4;

import java.util.Set;

public class CollectionBean2 {
	private Set<String> addressSet;

	
	public void setAddressSet(Set<String> addressSet) {
		this.addressSet = addressSet;
	}
	
	public Set<String> getAddressSet() {
		return addressSet;
	}
}
