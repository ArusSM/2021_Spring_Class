package com.yydh.myapp4;

import java.util.Map;

public class CollectionBean3 {
	
	private Map<String, String> addressMap;
	
	public void setAddressMap(Map<String, String> addressMap) {
		this.addressMap = addressMap;
	}
	
	public Map<String, String> getAddressMap() {
		return addressMap;
	}
}
