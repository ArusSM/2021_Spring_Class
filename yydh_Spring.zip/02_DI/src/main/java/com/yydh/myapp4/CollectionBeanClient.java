package com.yydh.myapp4;

import java.util.Map;
import java.util.Set;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class CollectionBeanClient {

	public static void main(String[] args) {
//		AbstractApplicationContext factory 
//		= new GenericXmlApplicationContext("applicationContext6.xml");
//		
//		CollectionBean2 bean = (CollectionBean2)factory.getBean("collectionBean");
//		
//		Set<String> addressList = bean.getAddressSet();
//		
////		for (int i = 0; i < addressList.size(); i++) {
////			System.out.println(addressList.toString());
////		}
//		
//		for(String address : addressList) {
//			System.out.println(address.toString());
//		}
//		
//		factory.close();
		
		
		AbstractApplicationContext factory 
		= new GenericXmlApplicationContext("applicationContext7.xml");
		
		CollectionBean3 bean = (CollectionBean3)factory.getBean("collectionBean");
		Map<String, String> addressMap = bean.getAddressMap();
		for(String address : addressMap.keySet()) {
			 String value = addressMap.get(address);
			 System.out.println(address + " : " + value);
		}
		
		factory.close();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
