package com.yydh.myapp;

public interface Speaker {

	void volumeUp();

	void volumeDown();

}