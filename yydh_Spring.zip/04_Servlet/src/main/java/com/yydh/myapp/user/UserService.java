package com.yydh.myapp.user;

public interface UserService {
	public UserVO getUser(UserVO vo);
}
