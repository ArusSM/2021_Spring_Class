package com.yydh.service.user;

import com.yydh.model.user.UserVO;

public interface UserService {
	public UserVO getUser(UserVO vo);
}
