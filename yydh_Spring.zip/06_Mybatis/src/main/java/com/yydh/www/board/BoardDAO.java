package com.yydh.www.board;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAO {
	
	private SqlSessionFactory sqlSessionFactory;
	private final String namespace = "BoardMapper";

	public BoardDAO() {
		InputStream inputStream = null;
		
		try {
			String resource = "mybatis-config.xml";
			inputStream = Resources.getResourceAsStream(resource);
		} catch (Exception e) {
			e.printStackTrace();
		}
		sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
	}
	
	
	public void insertBoard(BoardVO vo) {
		SqlSession session = sqlSessionFactory.openSession();
		try {
			session.insert(namespace+".insertData", vo);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(session!=null) session.close();
		} 
	}
	
	
	public void updateBoard(BoardVO vo) {
		SqlSession session = sqlSessionFactory.openSession();
		try {
			session.update(namespace+".updateData", vo);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(session!=null) session.close();
		}
	}
	
	public void deleteBoard(int seq) {
		SqlSession session = sqlSessionFactory.openSession();
		try {
			session.delete(namespace+".deleteData", seq);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(session!=null) session.close();
		}
	}	
	
	
	public BoardVO getBoard(int seq) {
		SqlSession session = sqlSessionFactory.openSession();
		BoardVO board = null;
		try {
			board = (BoardVO)session.selectOne(namespace+".selectOne", seq);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(session!=null) session.close();
		}
		return board;
	}
	
	public List<BoardVO> getBoardList() {
		SqlSession session = sqlSessionFactory.openSession();
		List<BoardVO> boardList = null;
		try {
			boardList = session.selectList(namespace + ".selectAll");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(session!=null)  session.close();
		}
		return boardList;
	}
	
	public List<BoardVO> searchBoardList(String keyword) {
		SqlSession session = sqlSessionFactory.openSession();
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		try {
			boardList = session.selectList(namespace+".searchData", keyword);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(session!=null) session.close();
		}
		return boardList;
	}
	
}
