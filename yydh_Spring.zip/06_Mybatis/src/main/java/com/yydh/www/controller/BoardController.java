package com.yydh.www.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.yydh.www.board.BoardDAO;
import com.yydh.www.board.BoardVO;

@Controller
public class BoardController {

	@Autowired
	BoardDAO dao;
	
	
	@RequestMapping("/getBoardList.do")
	public String getBoardList(BoardVO vo, Model model, HttpServletRequest request) {
		
		String searchString = request.getParameter("searchKeyword");
		System.out.println("searchKeyword is"+searchString);
		List<BoardVO> boardList = null;
		
		if(searchString != null) {
			model.addAttribute("boardList", dao.searchBoardList(searchString));
			return "getBoardList";	
		} 
		
		model.addAttribute("boardList", dao.getBoardList());
		return "getBoardList";
	}
	
	@RequestMapping("/getBoard.do")
	public String getBoard(BoardVO vo, Model model) {
		model.addAttribute("board", dao.getBoard(vo.getSeq()));
		return "getBoard";
	}

	@RequestMapping("/insertBoard.do")
	public String insertBoard(BoardVO vo) {
		dao.insertBoard(vo);
		return "redirect:getBoardList.do";
	}
	
	@RequestMapping("/updateBoard.do")
	public String updateBoard(BoardVO vo) {
		dao.updateBoard(vo);
		return "redirect:getBoardList.do";
	}
	
	@RequestMapping("/deleteBoard.do")
	public String deleteBoard(BoardVO vo) {
		dao.deleteBoard(vo.getSeq());
		return "redirect:getBoardList.do";
	}
	
} 
