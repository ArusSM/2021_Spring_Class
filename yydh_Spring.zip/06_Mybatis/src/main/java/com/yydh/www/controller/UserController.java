package com.yydh.www.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.yydh.www.user.UserDAO;
import com.yydh.www.user.UserVO;

@Controller
public class UserController {

	@Autowired
	UserDAO dao;

	
	// login.jsp -> id/pw -> login.do
	@RequestMapping("/login.do")
	public String login(UserVO vo, Model model, HttpSession session) {
		
		UserVO user = dao.getUser(vo);
		if (user != null) {
//			session.setAttribute("userName", user.getName());
			return "redirect:getBoardList.do";
		}
		
		return "login.jsp";
	}
	
	
	
	

}
