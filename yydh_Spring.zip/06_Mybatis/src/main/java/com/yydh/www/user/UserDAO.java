package com.yydh.www.user;

import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.stereotype.Repository;


@Repository
public class UserDAO {

	private SqlSessionFactory sqlSessionFactory;
	private final String namespace = "UserMapper";

	public UserDAO() {
		InputStream inputStream = null;
		
		try {
			String resource = "mybatis-config.xml";
			inputStream = Resources.getResourceAsStream(resource);
		} catch (Exception e) {
			e.printStackTrace();
		}
		sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
	}
	
	
	public UserVO getUser(UserVO vo) {
		SqlSession session = sqlSessionFactory.openSession();
		UserVO user = null;
		
		try {
			user = session.selectOne(namespace+".selectAll", vo);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(session != null) {
				session.close();
			}
		}
		return user;
	}
	
	
}
